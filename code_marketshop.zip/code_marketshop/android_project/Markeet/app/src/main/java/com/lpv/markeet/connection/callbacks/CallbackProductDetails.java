package com.lpv.markeet.connection.callbacks;

import com.lpv.markeet.model.Product;

import java.io.Serializable;

public class CallbackProductDetails implements Serializable {

    public String status = "";
    public Product product = null;

}
