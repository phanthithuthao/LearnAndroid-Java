package com.lpv.markeet.model;

import java.io.Serializable;

public class BuyerProfile implements Serializable {

    public String name;
    public String email;
    public String phone;
    public String address;

}
