package com.lpv.markeet.connection.callbacks;

import com.lpv.markeet.model.Info;

import java.io.Serializable;

public class CallbackInfo implements Serializable {
    public String status = "";
    public Info info = null;
}
