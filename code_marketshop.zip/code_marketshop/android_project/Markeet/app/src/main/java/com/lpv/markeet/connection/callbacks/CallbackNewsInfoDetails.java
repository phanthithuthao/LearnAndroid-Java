package com.lpv.markeet.connection.callbacks;

import com.lpv.markeet.model.NewsInfo;

import java.io.Serializable;

public class CallbackNewsInfoDetails implements Serializable {

    public String status = "";
    public NewsInfo news_info = null;

}
